package chap03_loop_assignment;

import java.util.Scanner;
public class Loop3 {
	//한 개의 자연수 입력받아 
	//그 수의 배수를 차례대로 10개 출력
	//ex) 5 -> 5 10 15 20 25 ... 50
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("숫자를 입력하시오: ");
		int number = sc.nextInt();

		if(number>0) {
			for(int i=number; i<=number*10; i++) {
				if(i%number==0) {
					System.out.print(i+" ");
				}
			}


		}

	}
}
