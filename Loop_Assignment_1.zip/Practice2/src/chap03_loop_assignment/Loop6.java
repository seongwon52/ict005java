package chap03_loop_assignment;

import java.util.Scanner;
public class Loop6 {
	//삼각형 밑변, 높이 입력받아 넓이 출력
	//"Continue?"에서 하나의 문자 입력받아 그 문자가 'Y'/'y'이면 작업 반복
	//다른 문자이면 종료
	//넓이는 반올림해서 소수 첫째자리까지 출력
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		String answer;
		
		do {
			System.out.print("Base = ");
			double base = sc.nextDouble();

			System.out.print("Height = ");
			double height = sc.nextDouble();

			double width = base*height*1/2;
			System.out.println("Triangle width = " + Math.round(width*10)/10.0);


			System.out.print("Continue? ");
			answer = sc.next();

		} while(answer.equals("Y") || answer.equals("y"));


	}

}

