package chap03_loop_assignment;

import java.util.Scanner;
public class Loop4 {
	//100이하 양의 정수만
	//while문 사용
	//1부터 입력받은 정수까지의 합 출력
	//ex) 10 -> 55
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("숫자를 입력하시오: ");
		int number = sc.nextInt();

		if(number>0 && number<=100) {
			
			int i=1;
			int sum=0;
			
			while(i<=number) {
				sum+=i;
				i++;
			} System.out.println(sum);

		}

	}
}
