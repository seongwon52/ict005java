package chap03_loop_assignment;

import java.util.Scanner;
public class Loop1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("숫자를 입력하시오: ");
		int number = sc.nextInt();

		if(number<=100 && number>0) {
			int sum=0;
			int i=1;
			
			while(i<number+1) {
				sum+=i;
				i++;

			} System.out.println(sum);

		}

	}
}
