package chap03_loop_assignment;
//100이하 정수 입력받아 입력받은 정수로부터 100까지의 합
//ex) 95 -> 585
import java.util.Scanner;
public class Loop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("숫자를 입력하시오: ");
		int number = sc.nextInt();

		if(number<=100) {
			int sum = 0;
			
			for(int i=number; i<=100; i++) {
				sum+=i;
			} System.out.println(sum);

		}

	}
}
