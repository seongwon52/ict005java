package chap03_loop_assignment;

public class Loop7 {
	// 2 3 4 5 6
	// 3 4 5 6 7
	// 4 5 6 7 8
	// 5 6 7 8 9 
	// 6 7 8 9 10
	public static void main(String[] args) {
		// TODO Auto-generated method stub


		for(int i=0; i<5; i++) {
			for(int j=2; j<=6; j++) {

				System.out.print(j+i+" ");

			} System.out.println(" ");
		}
	}

}
