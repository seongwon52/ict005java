package chap03_loop_assignment;

import java.util.Scanner;
public class Loop5 {
	//0이 입력될 때까지 정수 계속 입력받아
	//3의 배수와 5의 배수를 제외한 수들의 개수 출력
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int number;
		int sum=0;

		for(int i=1; i>0; i++) {
			System.out.print("숫자를 입력하시오: ");
			number = sc.nextInt();
			
			if(number==0) break;

			else if(number%3!=0 && number%5!=0) {
				sum+=1;
			}

		}System.out.println(sum);



	}

}
