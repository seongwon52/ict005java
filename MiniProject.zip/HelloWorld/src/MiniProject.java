
public class MiniProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(20+10);
		System.out.println(20-10);
		System.out.println(20*10);
		System.out.println(20/10);
	}

}
