package chap04_MiniProject;

public class Dice {
	
	private int value;
	
	public Dice() {
		value = 0;
	}
	
	public void roll() {
		value = (int)(Math.random()*6+1);
	}
	public int getValue() {return value;}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//private int value=(int)(Math.random()*1+6);
//	private int value;
//	
//	public void roll() {
//		value = (int)(Math.random()*1+6);
//	}
//	public int getValue() {return ;}
//	
	
	
	
//	public int roll() { return (int)(Math.random()*1+6);}
	
	
	
	
	
}
