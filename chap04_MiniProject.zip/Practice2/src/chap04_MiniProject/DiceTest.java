package chap04_MiniProject;

public class DiceTest {

	public static void main(String[] args) {
		Dice d1 = new Dice();
		Dice d2 = new Dice();

		int count=0;
		while(true) {

			System.out.println("주사위1= "+d1.getValue()+" 주사위2= "+d2.getValue());

			count+=1;
			if(d1.getValue()+d2.getValue()==2) break;
			else if(d1.getValue()+d2.getValue()!=2){
				d1.roll();
				d2.roll();
				d1.getValue();
				d2.getValue();
				continue;
			}
		}
		System.out.println("(1, 1)이 나오는데 걸린 횟수= "+count);






		//		Dice d1 = new Dice();
		//		Dice d2 = new Dice();
		//		
		//		int count=0;
		//		while(true) {
		//			System.out.println("주사위1= "+d1.getValue()+" 주사위2= "+d2.getValue());
		//			int x = d1.getValue();
		//			int y = d2.getValue();
		//			count+=1;
		//			if(x+y==2) break;
		//			
		//		}
		//		System.out.println("(1, 1)이 나오는데 걸린 횟수= "+count);

	}

}
