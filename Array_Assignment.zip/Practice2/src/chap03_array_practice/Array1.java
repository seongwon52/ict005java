package chap03_array_practice;

import java.util.Scanner;
public class Array1 {
	//10개 문자 입력받고
	//첫 번째 네 번째 일곱 번째 입력받은 문자 차례로 출력
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		String[] x = new String[10];

		System.out.print("문자를 입력하시오: ");
		for(int i=0; i<x.length; i++) {
			x[i] = sc.next();
		}
		System.out.print(x[0]+" "+x[3]+" "+x[6]+" ");
	}
}
