package chap03_array_practice;

import java.util.Scanner;
public class Array6 {
	//10개 정수 입력받고
	//그 중 가장 작은 수를 출력
	//입력받을 정수는 1000 넘지 않음
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int[] numbers = new int[10];

		System.out.print("숫자를 입력하시오: ");

		for(int i=0; i<numbers.length; i++) {
			numbers[i] = sc.nextInt();
			if(numbers[i]>=1000) {
				System.out.println("error"); break;
			}
		}
		//5 10 8 55 6 31 12 24 61 2 -> 2
		int a = numbers[0];
		int b = numbers[0];

		for(int i=1; i<numbers.length; i++) {
			if(a>numbers[i]) {
				a=numbers[i];
				
			}
			else if(b<numbers[i]) {
				b=numbers[i];
			}
		} if(b<1000) 
			System.out.println(a);
	}
}



