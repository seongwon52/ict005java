package chap03_array_practice;

import java.util.Scanner;
public class Array4 {
	//10개 정수 입력받아 배열에 저장한 다음
	//짝수 번째 입력된 값의 합과
	//홀수 번째 입력된 값의 합의 평균 출력
	//평균은 반올림하여 소수 첫째자리까지 출력
	//95 100 88 65 76 89 58 93 77 99 -> sum: 446, avg: 78.8
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int[] numbers = new int[10];

		int sum1=0, sum2=0;

		System.out.print("숫자를 입력하시오: ");
		for(int i=0; i<numbers.length; i++) {
			numbers[i] = sc.nextInt();

			if(i%2!=0) {
				sum1+=numbers[i];
			}
			else if(i%2==0 || i==0) {
				sum2+=numbers[i];
			}
		}
		double avg = (double)sum2/5;

		System.out.println("sum: "+sum1);
		System.out.println("avg: "+Math.round(avg*10)/10.0);
	}
}
