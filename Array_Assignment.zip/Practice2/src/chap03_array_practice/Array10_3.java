package chap03_array_practice;

import java.util.Scanner;
public class Array10_3 {
	//4행 2열의 배열을 받고
	//가로평균과 세로평균 그리고 전체평균 출력
	//소수점 이하는 버림
	//16 27    ->    21 69 53 40
	//39 100         33 58
	//19 88          46
	//61 20       
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int[][] a1 = new int[4][2];

		int sum3=0;
		int[] sum1 = new int[4];
		int[] sum2 = new int[2];
		System.out.println("숫자를 입력하시오: ");
		for(int i=0; i<4; i++) {
			for(int k=0; k<2; k++) {
				a1[i][k] = sc.nextInt();
				sum1[i] += a1[i][k];
				sum3 += a1[i][k];
			}
		}
		//16 27 39 100 19 88 61 20
		int x;
		for(int i=0; i<4; i++) {
			x=sum1[i]/2;
			System.out.print(x+" ");
		} 
		System.out.println();
		
		int y;
		for(int i=0; i<2; i++) {
			for(int k=0; k<4; k++) {
				sum2[i] += a1[k][i];
			}
			y=sum2[i]/4;
			System.out.print(y+" ");
		} 
		System.out.println();
		
		int avg3 = sum3/8;
		System.out.println(avg3);
	}
}
