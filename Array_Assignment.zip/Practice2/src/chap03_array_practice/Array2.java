package chap03_array_practice;

import java.util.Scanner;
public class Array2 {
	//6명의 몸무게를 입력받고 몸무게 평균 출력
	//출력은 반올림해서 소수 첫째자리까지
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		double[] weight = new double[6];

		double sum=0;

		System.out.print("몸무게를 입력하시오: ");
		for(int i=0; i<weight.length; i++) {
			weight[i] = sc.nextDouble();
			sum+=weight[i];
		}
		double avg = sum/6;

		System.out.print("평균 몸무게: "+Math.round(avg*10)/10.0);
	}
}
