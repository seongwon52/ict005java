package chap03_array_practice;

import java.util.Scanner;
public class Array5 {
	//100개 정수 저장할 수 있는 배열 선언하고
	//정수 차례로 입력받다가 0 입력하면 
	//0 제외 그때까지 입력된 정수를 가장 나중에 입력된 정수부터 차례로 출력
	//ex) 3 5 10 55 0 -> 55 10 5 3
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int[] numbers = new int[100];
		
		System.out.print("숫자를 입력하시오: ");
		for(int i=0; i<numbers.length; i++) {
			numbers[i] = sc.nextInt();
			if(numbers[i]==0) break;
		}
		for(int i=numbers.length-1; i>=0; i--) {
			if(numbers[i]!=0) {
				System.out.print(numbers[i]+" ");
			}
		}
	}
}
