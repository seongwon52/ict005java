package chap03_array_practice;

import java.util.Scanner;
public class Array9_2 {
	//네 반이 있고 반별로 세 명이 제기 찬 개수 입력받고
	//각 반별로 제기 찬 개수의 합계 출력
	//15 2 35
	//33 1 6
	//5 10 19
	//1 8 55
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int[][] num = new int[4][3];
		int[] sum = new int[4];
		
		for(int i=0; i<num.length; i++) {
			System.out.print(i+1+"class? ");
			for(int k=0; k<num[i].length; k++) {
				num[i][k] = sc.nextInt();
				sum[i] += num[i][k];
			}
		}
		System.out.println();
		
		for(int i=0; i<sum.length; i++) {
			System.out.println(i+1+"class: "+sum[i]);
		}
	}
}
