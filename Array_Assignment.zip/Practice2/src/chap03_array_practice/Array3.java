package chap03_array_practice;

import java.util.Scanner;
public class Array3 {
	//1반부터 6반까지 평균점수를 지정한 후
	//두 반의 반 번호를 입력받아
	//두 반 평균점수의 합 출력
	//반 별 평균점수 1반부터 차례로: 85.6, 79.5, 83.1, 80.0, 78.2, 75.0
	//출력은 소수 두 번째 자리에서 반올림하여 소수 첫째자리까지 나타냄
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		double[] score = {85.6, 79.5, 83.1, 80.0, 78.2, 75.0};

		int num1, num2;
		System.out.print("반 번호를 입력하시오: ");
		num1 = sc.nextInt()-1;
		num2 = sc.nextInt()-1;

		double sum = score[num1]+score[num2];
		System.out.print(Math.round(sum*100)/100.0);
	}
}
