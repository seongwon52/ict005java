package chap03_array_practice;

import java.util.Scanner;
public class Array8_4 {
	//2행 4열의 배열 두 개 만들어서 입력 받고
	//두 배열의 곱을 구하여 출력
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int[][] a1 = new int[2][4];
		int[][] a2 = new int[2][4];
		//1 2 3 4 5 6 7 8
		//1 4 7 8 3 6 9 8
		System.out.println("first array");
		for(int i=0; i<a1.length; i++) {
			for(int k=0; k<a1[i].length; k++) {
				a1[i][k] = sc.nextInt();
			}
		}
		System.out.println("second array");
		for(int i=0; i<a2.length; i++) {
			for(int k=0; k<a2[i].length; k++) {
				a2[i][k] = sc.nextInt();
			}
		}
		int[][] a3 = new int[a1.length][a1[0].length];
		for(int i=0; i<a1.length; i++) {
			for(int k=0; k<a1[0].length; k++) {
				a3[i][k] = a1[i][k] * a2[i][k];
			}
		}
		for(int[]e: a3) {
			for(int f: e) {
				System.out.print(f+" ");
			}
			System.out.println();
		}
	}
}

