
package chap03_array_practice;

import java.util.Scanner;
public class Array7_4 {
	//100미만의 양의 정수 입력받다가
	//0 입력되면 0 제외 그때까지 입력된 정수의 십의 자리 숫자가 각각 몇 개인지
	//작은 수부터 출력(0개인 숫자는 출력X)
	//10 55 3 63 85 61 85 0 -> 0:1, 1:1, 5:1, 6:2, 8:2
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int c0=0, c1=0, c2=0, c3=0, c4=0, c5=0, c6=0, c7=0, c8=0, c9=0;
		int number=0;
		
		System.out.print("숫자를 입력하시오: ");
		while(true){
			number = sc.nextInt();
			if(number==0) break;
			number = number/10;
			switch(number) {
			case 1: c1+=1; break;
			case 2: c2+=1; break;
			case 3: c3+=1; break;
			case 4: c4+=1; break;
			case 5: c5+=1; break;
			case 6: c6+=1; break;
			case 7: c7+=1; break;
			case 8: c8+=1; break;
			case 9: c9+=1; break;
			default: c0+=1; break;
			}
		}
		int[] y = {c0, c1, c2, c3, c4, c5, c6, c7, c8, c9};
		for(int i=0; i<y.length; i++) {
			if(y[i]>=1) {
				System.out.println(i+": "+y[i]);
			}
		}
	}
}
