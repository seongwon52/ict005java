package chap03_loop_assignment2;

import java.util.Scanner;
public class LoopA3 {
	//행, 열의 수를 입력받아 출력
	//ex) 3 4
	//1 2 3 4
	//2 4 6 8
	//3 6 9 12
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("행의 개수를 입력하시오: ");
		int row = sc.nextInt();

		System.out.print("열의 개수를 입력하시오: ");
		int column = sc.nextInt();

		for(int i=1; i<=row; i++) {
			for(int j=1; j<=column; j++) {
				System.out.print(i*j+" ");
			}System.out.println(" ");
		}
	}
}
