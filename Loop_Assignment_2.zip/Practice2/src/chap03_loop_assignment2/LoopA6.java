package chap03_loop_assignment2;

import java.util.Scanner;
public class LoopA6 {
	//1부터 100까지 정수 중 한 개 입력받고
	//100보다 작은 배수들 차례로 출력하다가
	//10의 배수 되면 종료
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("숫자를 입력하시오: ");
		int number = sc.nextInt();

		if(number>=1 && number<=100) {
			for(int i=number; i>0; i++) {
				if(i%number==0) {
					System.out.print(i+" ");
					if(i%10==0) break;
					}
				}
			}
		}
	}

