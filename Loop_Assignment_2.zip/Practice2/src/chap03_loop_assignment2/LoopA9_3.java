package chap03_loop_assignment2;

import java.util.Scanner;
public class LoopA9_3 {
	//자연수 n 입력받아 n x n 크기에 공백으로 구분하여 출력
	//10미만의 홀수만
	//줄 사이에 빈 줄 없게
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("자연수를 입력하시오: ");
		int number = sc.nextInt();
		int count=1;
		
		for(int i=0; i<number; i++) {
			for(int k=0; k<number; k++) {
				if(count>10) {
					count=1;
				}
				System.out.print(count+" ");
				count+=2;
			}
			System.out.println();
		}
	}
}
