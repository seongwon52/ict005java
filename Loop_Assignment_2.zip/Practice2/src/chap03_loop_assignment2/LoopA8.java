package chap03_loop_assignment2;

import java.util.Scanner;
public class LoopA8 {
	//자연수 n 입력받아서 아래와 같이 출력
	//ex) 3 입력하면
	// 1 2 3 
	//   4 5
	//     6
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("자연수를 입력하시오: ");
		int number = sc.nextInt();
		int count=0;
		
		if(number>0) {
			for(int i=number; i>=1; i--) {
				for(int k=number; k>i; k--) {
					System.out.print("  ");
				}
				for(int j=1; j<=i; j++) {
					count++;
					System.out.print(count+" ");
				}
				System.out.println();
			}
		}
	}
}
