package chap03_loop_assignment2;

import java.util.Scanner;
public class LoopA5 {
	//자연수 n 입력받아서 아래와 같이 출력
	//ex) 3 입력했을 때
	//* * * * *
	//  * * *
	//    *
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("자연수를 입력하시오: ");
		int number = sc.nextInt();

		if(number>0) {
			for(int i=1; i<=number+number-1; i=i+2) {
				for(int k=1; k<i; k=k+2) {
					System.out.print("  ");
				}
				for(int j=number+number-1; j>=i; j--) {
					System.out.print("*"+" ");
				}
				System.out.println();
			}
		}
	}
}
