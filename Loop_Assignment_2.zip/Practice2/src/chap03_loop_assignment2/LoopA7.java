package chap03_loop_assignment2;

import java.util.Scanner;
public class LoopA7 {
	//ex) 3 입력하면 아래와 같이 출력
	//     1
	//   1 2
	// 1 2 3 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("숫자를 입력하시오: ");
		int number = sc.nextInt();

		for(int i=1; i<=number; i++) {
			for(int k=number; k>i; k--) {
				System.out.print("  ");
			}
			for(int j=1; j<=i; j++) {
				System.out.print(j+" ");
			} 
			System.out.println("");
		}
	}
}

