package chap03_loop_assignment2;

import java.util.Scanner;
public class LoopA1_2 {
	//자연수 n 입력받고
	//1부터 홀수 차례대로 더해나가면서
	//합이 n 이상이면 그때까지 더해진 홀수 개수와 그 합 출력
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int number;
		System.out.print("자연수를 입력하시오: ");
		number = sc.nextInt();

		int sum=0;
		int sum2=0;
		int i=0;

		do {
			i++;
			if(i%2!=0) {
				sum+=1; sum2+=i;
			}
		} while(sum2<number);

		System.out.print(sum+" ");
		System.out.print(sum2);
	}
}
