package chap03_loop_assignment2;

import java.util.Scanner;
public class LoopA2 {
	//2부터 9까지 수 중 2개를 입력받아
	//입력받은 수 사이의 구구단 출력
	//ex) 5 3 -> 3, 4, 5단 출력
	//구구단 사이 공백 3칸
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int number1=0;
		int number2=0;

		System.out.print("숫자를 입력하시오: ");
		number1 = sc.nextInt();
		number2 = sc.nextInt();

		if(number1>=2 && number1<=9 || number2>=2 && number2<=9) {
			int sum=0; 
			if(number1>number2) {
				for(int i=1; i<=9; i++) {
					for(int j=number1; j>=number2; j--) {
						System.out.printf("%d*%d= %2d   ", j, i, j*i);
					} System.out.println(" ");
				}
			}
			else {
				for(int i=1; i<=9; i++) {
					for(int j=number2; j>=number1; j--) {
						System.out.printf("%d*%d= %2d   ", j, i, j*i);
					} System.out.println(" ");
				}
			}
		}
	}
}
